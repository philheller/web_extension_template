"use strict";(()=>{function t(e,n){return e+n}function o(){chrome.runtime.sendMessage({message:"incrementCounter"},function(e){console.log(e.result)})}var r=document.querySelector("body");r?.addEventListener("click",()=>o());})();
//# sourceMappingURL=contentScript.js.map
